(globalThis["webpackChunk"] = globalThis["webpackChunk"] || []).push([["locale/no"],{

/***/ "../src/sentry/locale/no/LC_MESSAGES/django.po":
/*!*****************************************************!*\
  !*** ../src/sentry/locale/no/LC_MESSAGES/django.po ***!
  \*****************************************************/
/***/ ((module) => {

module.exports = {"":{"domain":"sentry","plural_forms":"nplurals=2; plural=(n != 1);","lang":"no"}};

/***/ })

}]);
//# sourceMappingURL=../../sourcemaps/locale/no.3ebbda5446ed7ea4085f06d07c9fb71f.js.map