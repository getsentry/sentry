(globalThis["webpackChunk"] = globalThis["webpackChunk"] || []).push([["locale/ru-ru"],{

/***/ "../src/sentry/locale/ru_RU/LC_MESSAGES/django.po":
/*!********************************************************!*\
  !*** ../src/sentry/locale/ru_RU/LC_MESSAGES/django.po ***!
  \********************************************************/
/***/ ((module) => {

module.exports = {"":{"domain":"sentry","plural_forms":"nplurals=4; plural=(n%10==1 && n%100!=11 ? 0 : n%10>=2 && n%10<=4 && (n%100<12 || n%100>14) ? 1 : n%10==0 || (n%10>=5 && n%10<=9) || (n%100>=11 && n%100<=14)? 2 : 3);","lang":"ru_RU"}};

/***/ })

}]);
//# sourceMappingURL=../../sourcemaps/locale/ru-ru.7c520e62728591f94b85070627cdfa24.js.map