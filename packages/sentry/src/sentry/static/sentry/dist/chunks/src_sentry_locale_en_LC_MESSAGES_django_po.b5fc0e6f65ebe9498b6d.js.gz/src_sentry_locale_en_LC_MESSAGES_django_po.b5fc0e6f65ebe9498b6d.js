(globalThis["webpackChunk"] = globalThis["webpackChunk"] || []).push([["src_sentry_locale_en_LC_MESSAGES_django_po"],{

/***/ "../src/sentry/locale/en/LC_MESSAGES/django.po":
/*!*****************************************************!*\
  !*** ../src/sentry/locale/en/LC_MESSAGES/django.po ***!
  \*****************************************************/
/***/ ((module) => {

module.exports = {"":{"domain":"sentry","plural_forms":"nplurals=2; plural=(n != 1)","lang":"en"}};

/***/ })

}]);
//# sourceMappingURL=../sourcemaps/src_sentry_locale_en_LC_MESSAGES_django_po.a3078c1af302f7c9f83fff915f2e3273.js.map