(globalThis["webpackChunk"] = globalThis["webpackChunk"] || []).push([["locale/ach"],{

/***/ "../src/sentry/locale/ach/LC_MESSAGES/django.po":
/*!******************************************************!*\
  !*** ../src/sentry/locale/ach/LC_MESSAGES/django.po ***!
  \******************************************************/
/***/ ((module) => {

module.exports = {"":{"domain":"sentry","plural_forms":"nplurals=2; plural=(n > 1);","lang":"ach"}};

/***/ })

}]);
//# sourceMappingURL=../../sourcemaps/locale/ach.84a08dfe38b50ff0655bd38592717d6b.js.map