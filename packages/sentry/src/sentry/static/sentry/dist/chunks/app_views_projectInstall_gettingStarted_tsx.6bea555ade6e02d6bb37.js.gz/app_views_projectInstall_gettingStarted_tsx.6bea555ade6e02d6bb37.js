"use strict";
(globalThis["webpackChunk"] = globalThis["webpackChunk"] || []).push([["app_views_projectInstall_gettingStarted_tsx"],{

/***/ "./app/views/projectInstall/gettingStarted.tsx":
/*!*****************************************************!*\
  !*** ./app/views/projectInstall/gettingStarted.tsx ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/styled/base */ "../node_modules/@emotion/styled/base/dist/emotion-styled-base.browser.esm.js");
/* harmony import */ var sentry_styles_organization__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! sentry/styles/organization */ "./app/styles/organization.tsx");
/* harmony import */ var sentry_styles_space__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! sentry/styles/space */ "./app/styles/space.tsx");




const GettingStarted = /*#__PURE__*/(0,_emotion_styled_base__WEBPACK_IMPORTED_MODULE_0__["default"])(sentry_styles_organization__WEBPACK_IMPORTED_MODULE_1__.PageContent,  true ? {
  target: "e54y2ot0"
} : 0)("background:", p => p.theme.background, ";padding-top:", (0,sentry_styles_space__WEBPACK_IMPORTED_MODULE_2__["default"])(3), ";" + ( true ? "" : 0));

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (GettingStarted);

/***/ })

}]);
//# sourceMappingURL=../sourcemaps/app_views_projectInstall_gettingStarted_tsx.f45bd325c74a8abdbe3dc7a78f8ae08c.js.map