(globalThis["webpackChunk"] = globalThis["webpackChunk"] || []).push([["locale/ro-ro"],{

/***/ "../src/sentry/locale/ro_RO/LC_MESSAGES/django.po":
/*!********************************************************!*\
  !*** ../src/sentry/locale/ro_RO/LC_MESSAGES/django.po ***!
  \********************************************************/
/***/ ((module) => {

module.exports = {"":{"domain":"sentry","plural_forms":"nplurals=3; plural=(n==1?0:(((n%100>19)||((n%100==0)&&(n!=0)))?2:1));","lang":"ro_RO"}};

/***/ })

}]);
//# sourceMappingURL=../../sourcemaps/locale/ro-ro.539b267740b6ff29961a073b5f26f4c4.js.map