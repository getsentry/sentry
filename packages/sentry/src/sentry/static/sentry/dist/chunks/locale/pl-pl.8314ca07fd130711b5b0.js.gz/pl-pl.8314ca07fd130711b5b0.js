(globalThis["webpackChunk"] = globalThis["webpackChunk"] || []).push([["locale/pl-pl"],{

/***/ "../src/sentry/locale/pl_PL/LC_MESSAGES/django.po":
/*!********************************************************!*\
  !*** ../src/sentry/locale/pl_PL/LC_MESSAGES/django.po ***!
  \********************************************************/
/***/ ((module) => {

module.exports = {"":{"domain":"sentry","plural_forms":"nplurals=3; plural=(n==1 ? 0 : n%10>=2 && n%10<=4 && (n%100<10 || n%100>=20) ? 1 : 2);","lang":"pl_PL"}};

/***/ })

}]);
//# sourceMappingURL=../../sourcemaps/locale/pl-pl.dffeff0fdbacfb67b084a01bf3ef5059.js.map